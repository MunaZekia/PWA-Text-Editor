const maxSumArray = function(numbers) {
  // Write your solution here
};
