// Write a function that takes in an integer and returns it as a Roman numeral string

var intToRoman = function(num) {};
