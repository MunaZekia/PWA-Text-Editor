import OmdbContainer from './components/OmdbContainer';

export default function App() {
  return <OmdbContainer />;
}
