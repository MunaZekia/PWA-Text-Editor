import React from 'react';
import Form from './components/Form/index';

function App() {
  return <Form />;
}

export default App;
