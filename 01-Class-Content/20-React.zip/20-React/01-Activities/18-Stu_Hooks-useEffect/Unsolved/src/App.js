import React from 'react';
import Thermostat from './components/Thermostat';

function App() {
  return <Thermostat />;
}

export default App;
