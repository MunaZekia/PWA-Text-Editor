import React from 'react';
// TODO: Add a comment explaining what this import statement is doing
import HelloReact from './components/HelloReact';

// TODO: Add a comment explaining the purpose of the App component
function App() {
  return <HelloReact />;
}

export default App;
