import React from 'react';

// TODO: Add a comment explaining what a react component is
function HelloReact() {
  const text = 'some text';

  // TODO: Add a comment explaining what JSX is and the significance of the curly braces
  return <p>Hello World! Here is {text}</p>;
}

export default HelloReact;
