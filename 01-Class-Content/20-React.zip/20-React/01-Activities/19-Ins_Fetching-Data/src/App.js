import React from 'react';
import SearchResultContainer from './components/SearchResultContainer';

function App() {
  return <SearchResultContainer />;
}

export default App;
