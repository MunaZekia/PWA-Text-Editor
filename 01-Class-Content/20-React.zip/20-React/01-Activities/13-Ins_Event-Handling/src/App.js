import React from 'react';
import Counter from './components/Counter';

function App() {
  return <Counter />;
}

export default App;
